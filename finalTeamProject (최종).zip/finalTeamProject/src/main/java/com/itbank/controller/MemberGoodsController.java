package com.itbank.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MemberGoodsController {

    
}
