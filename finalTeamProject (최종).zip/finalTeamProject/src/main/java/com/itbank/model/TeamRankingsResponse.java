package com.itbank.model;

import java.util.List;

public class TeamRankingsResponse {

	  private List<TeamRankingDTO> content;

	public List<TeamRankingDTO> getContent() {
		return content;
	}

	public void setContent(List<TeamRankingDTO> content) {
		this.content = content;
	}
	  
	  
	
	  
}
