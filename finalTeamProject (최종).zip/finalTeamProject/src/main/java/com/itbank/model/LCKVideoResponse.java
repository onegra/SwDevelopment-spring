package com.itbank.model;

import java.util.List;

public class LCKVideoResponse {

	private List<LCKVideoDTO> content;

	public List<LCKVideoDTO> getContent() {
		return content;
	}

	public void setContent(List<LCKVideoDTO> content) {
		this.content = content;
	}
	
}
